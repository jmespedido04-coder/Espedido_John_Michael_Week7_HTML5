Web Development Project: Portfolio Website

Student Information
Student Name: John Michael Espedido
Course / Section: BSIT 3 WMAD
Date: September 18, 2026

Website Purpose
    The purpose of this website is to demonstrate a solid foundational understanding of semantic HTML5, responsive layout design, and web accessibility best practices.

    The website consists of three main pages:

    Home (index.html): Introduces the website, highlights key web development principles, includes featured images with captions, and provides internal/external navigation.

    About (about.html): Describes the author's background, core technical skills, and supplementary notes on web accessibility using semantic articles and asides.

    Projects (projects.html): Showcases featured work and includes a accessible data table displaying project metadata and status.

File Structure 

    Espedido_John_Michael_Week7_HTML5
    |
    L css
    |  L style.css    # Contains Styles for all pages
    |
    L images
    |  L profile.jpg  # Image used in homepage
    |
    L about.html      # About page about personal info and skills list
    L index.html      # Home page with overview
    L project.html    # Projects page with featuring project
    L README.md       # Project documentation

Validation

    Page Language:    
    Required Evidence: Has the right lang="en" attribute on the <html> tag            
    Status: PASS
    
    Headings:
    Required Evidence: Every page follows a logical heading hierarchy
    Status: PASS
    
    Navigation:
    Required Evidence: Link text describes its destination
    Status: PASS
    
    Images:
    Required Evidence: Informative images have meaningful alt text
    Status: PASS
    
    Tables:
    Required Evidence: Table includes caption, headings, and scope
    Status: PASS
    
    Semantics:
    Required Evidence: <header>, <nav>, <main>, <section>, <article>, <aside>, and <footer> are used correctly
    Status: PASS
    
    Color Independence:
    Required Evidence: Instructions do not rely on color alone
    Status: PASS